package org.example.basic.DesignPattern.Factory;

public interface Animal {

    String Character( );
}
