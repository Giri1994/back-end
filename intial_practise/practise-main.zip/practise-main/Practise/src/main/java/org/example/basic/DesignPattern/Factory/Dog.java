package org.example.basic.DesignPattern.Factory;

public class Dog implements Animal{
    @Override
    public String Character() {
        return "Bark";
    }
}
