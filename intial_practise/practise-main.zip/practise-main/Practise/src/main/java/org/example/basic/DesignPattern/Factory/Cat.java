package org.example.basic.DesignPattern.Factory;

public class Cat implements Animal{
    @Override
    public String Character() {
        return "Meow";
    }
}
