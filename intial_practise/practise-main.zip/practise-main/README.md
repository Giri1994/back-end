**To do any changes :**
1.git Clone [git@github.com:kandagirisudhan/practise.git](https://github.com/kandagirisudhan/practise.git)https://github.com/kandagirisudhan/practise.git    
2.Create a child branch     
3.Checkout to child branch git checkout child_branch .    
4.Make change -git commit    
5.Make change -git push     
